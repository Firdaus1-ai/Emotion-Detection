import cv2
import numpy as np
import dlib
from imutils import face_utils
import winsound

# Initializing the camera and taking the instance
cap = cv2.VideoCapture(0)

# Initializing the face detector and landmark detector
detector = dlib.get_frontal_face_detector()
predictor = dlib.shape_predictor("shape_predictor_68_face_landmarks.dat")

# Status marking for current state
sleep = 0
notfocus = 0
focus = 0
status = ""
color = (0, 0, 0)

# Constants for gaze estimation
GAZE_RATIO_THRESH = 2  # Adjust this threshold based on observations

def compute(ptA, ptB):
    return np.linalg.norm(np.array(ptA) - np.array(ptB))

def blinked(a, b, c, d, e, f):
    up = compute(b, d) + compute(c, e)
    down = compute(a, f)
    ratio = up / (2.0 * down)

    # Checking if it is blinked
    if ratio > 0.25:
        return 2  # Definite blink
    elif ratio > 0.21:
        return 1  # Possible blink (considered as not focused)
    else:
        return 0  # No blink
    
     # Checking if it is a possible blink
    if ratio > 0.21 and ratio <= 0.25:
        return True
    else:
        return False


def gaze_ratio(eye_points, landmarks):
    left_point = (landmarks[eye_points[0]][0], landmarks[eye_points[0]][1])
    right_point = (landmarks[eye_points[3]][0], landmarks[eye_points[3]][1])
    center_top = (landmarks[eye_points[1]][0], landmarks[eye_points[1]][1])
    center_bottom = (landmarks[eye_points[4]][0], landmarks[eye_points[4]][1])
    
    hor_line_length = compute(left_point, right_point)
    ver_line_length = compute(center_top, center_bottom)
    
    return hor_line_length / ver_line_length

while True:
    _, frame = cap.read()
    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)

    faces = detector(gray)
    # Detected face in faces array
    for face in faces:
        x1 = face.left()
        y1 = face.top()
        x2 = face.right()
        y2 = face.bottom()

        face_frame = frame.copy()
        cv2.rectangle(face_frame, (x1, y1), (x2, y2), (0, 255, 0), 2)

        landmarks = predictor(gray, face)
        landmarks = face_utils.shape_to_np(landmarks)

        left_gaze_ratio = gaze_ratio([36, 37, 38, 39, 40, 41], landmarks)
        right_gaze_ratio = gaze_ratio([42, 43, 44, 45, 46, 47], landmarks)
        gaze_ratio_value = (left_gaze_ratio + right_gaze_ratio) / 2.0

        left_eye_closed = landmarks[37][1] < landmarks[36][1] and landmarks[40][1] < landmarks[39][1]
        right_eye_closed = landmarks[44][1] < landmarks[45][1] and landmarks[47][1] < landmarks[42][1]
        
        left_blink = blinked(landmarks[36], landmarks[37],
                              landmarks[38], landmarks[41], landmarks[40], landmarks[39])
        right_blink = blinked(landmarks[42], landmarks[43],
                               landmarks[44], landmarks[47], landmarks[46], landmarks[45])
        	

        # Judge what to do for not focus and gaze ratio
        if left_blink == 0 and right_blink == 0:
            notfocus += 1
            focus = 0
            if notfocus > 6:
                status = "Not Focus :|"
                color = (0, 0, 255) 
            if notfocus > 200:
                status = "BANGUN WOII :/"
                winsound.Beep(1000, 500)  # Beep sound with 1000 Hz frequency for 500 milliseconds
                color = (128, 0, 128)   
                
        if left_eye_closed and right_eye_closed:
            sleep += 1
            notfocus = focus = 0
            if sleep > 6:
                status = "BANGUN WOII :/"
                winsound.Beep(1000, 500)  # Beep sound with 1000 Hz frequency for 500 milliseconds
                color = (128, 0, 128)  
                
        if left_blink == 0 or right_blink == 0:
            notfocus += 1
            focus = 0
            if notfocus > 6:
                status = "Not Focus :|"
                color = (0, 0, 255) 
            if notfocus > 200:
                status = "BANGUN WOII :/"
                winsound.Beep(1000, 500)  # Beep sound with 1000 Hz frequency for 500 milliseconds
                color = (128, 0, 128) 
            
        elif gaze_ratio_value < GAZE_RATIO_THRESH:
            notfocus += 1
            focus = 0
            if notfocus > 6:
                status = "Not Focus :|"
                color = (0, 0, 255)  
                
        else:
            notfocus = 0
            focus += 1
            if focus > 6:
                status = "Focus :)"
                color = (0, 255, 0)

        cv2.putText(frame, status, (100, 100), cv2.FONT_HERSHEY_TRIPLEX, 1.25, color, 3)

        # Draw landmarks for the whole face
        for (x, y) in landmarks:
            cv2.circle(frame, (x, y), 1, (255, 255, 255), -1)

    cv2.imshow("Result of detector", frame)
    key = cv2.waitKey(1)
    if key == 27:
        break

# Release the webcam and close windows
cap.release()
cv2.destroyAllWindows()