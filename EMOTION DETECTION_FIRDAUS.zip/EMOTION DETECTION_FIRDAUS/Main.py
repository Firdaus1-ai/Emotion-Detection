import cv2
import numpy as np
from keras.models import load_model
from keras.preprocessing.image import img_to_array
import dlib
from imutils import face_utils
import winsound
import threading
import time
import csv
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

# Load Haar Cascade Classifier and Pre-trained CNN Model for emotion detection
face_classifier = cv2.CascadeClassifier(r'C:\TRY2\Emotion_Detection_CNN-main\haarcascade_frontalface_default.xml')
classifier = load_model(r'C:\TRY2\Emotion_Detection_CNN-main\model.h5')

# Define Emotion Labels
emotion_labels = ['Angry', 'Disgust', 'Fear', 'Happy', 'Neutral', 'Sad', 'Surprise']

# Load dlib face detector and predictor for drowsiness detection
detector = dlib.get_frontal_face_detector()
predictor = dlib.shape_predictor("shape_predictor_68_face_landmarks.dat")

# Constants for gaze estimation
GAZE_RATIO_THRESH = 2  # Adjust this threshold based on observations

# Status marking for current state
sleep = 0
notfocus = 0
focus = 0
status = ""
color = (0, 0, 0)

# Utility functions for the second frame processing
def compute(ptA, ptB):
    return np.linalg.norm(np.array(ptA) - np.array(ptB))

def blinked(a, b, c, d, e, f):
    up = compute(b, d) + compute(c, e)
    down = compute(a, f)
    ratio = up / (2.0 * down)

    # Checking if it is blinked
    if ratio > 0.25:
        return 2  # Definite blink
    elif ratio > 0.21:
        return 1  # Possible blink (considered as not focused)
    else:
        return 0  # No blink

def gaze_ratio(eye_points, landmarks):
    left_point = (landmarks[eye_points[0]][0], landmarks[eye_points[0]][1])
    right_point = (landmarks[eye_points[3]][0], landmarks[eye_points[3]][1])
    center_top = (landmarks[eye_points[1]][0], landmarks[eye_points[1]][1])
    center_bottom = (landmarks[eye_points[4]][0], landmarks[eye_points[4]][1])

    hor_line_length = compute(left_point, right_point)
    ver_line_length = compute(center_top, center_bottom)

    return hor_line_length / ver_line_length

# Function to capture frames from webcam
def capture_frames():
    global frame
    cap = cv2.VideoCapture(0)
    while True:
        ret, frame = cap.read()
        if not ret:
            break
        # Exit on 'q' key press
        if cv2.waitKey(1) & 0xFF == ord('q'):
            break
    cap.release()

# Start the frame capturing thread
frame = None
capture_thread = threading.Thread(target=capture_frames)
capture_thread.start()

# Initialize CSV file to store emotion and engagement data
csv_file = open('emotion_engagement_data.csv', 'w', newline='')
csv_writer = csv.writer(csv_file)
csv_writer.writerow(['Real_Time', 'Emotion', 'Focus_Level', 'Engagement_Level'])

# Main loop
while True:
    if frame is None:
        continue
    
    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    
    # Create copies of the frame for different processing
    emotion_frame = frame.copy()
    focus_frame = frame.copy()

    # Emotion Detection
    faces = face_classifier.detectMultiScale(gray)
    for (x, y, w, h) in faces:
        cv2.rectangle(emotion_frame, (x, y), (x+w, y+h), (0, 255, 255), 2)
        roi_gray = gray[y:y+h, x:x+w]
        roi_gray = cv2.resize(roi_gray, (48, 48), interpolation=cv2.INTER_AREA)

        if np.sum([roi_gray]) != 0:
            roi = roi_gray.astype('float') / 255.0
            roi = img_to_array(roi)
            roi = np.expand_dims(roi, axis=0)

            prediction = classifier.predict(roi)[0]
            label_index = prediction.argmax()
            label = emotion_labels[label_index]

            # Display only the label without percentage
            label_text = f"{label}"
            label_position = (x, y)
            cv2.putText(emotion_frame, label_text, label_position, cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 0), 2)
        else:
            cv2.putText(emotion_frame, 'No Faces', (30, 80), cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 0), 2)

    faces = detector(gray)
    # Detected face in faces array
    for face in faces:
        x1 = face.left()
        y1 = face.top()
        x2 = face.right()
        y2 = face.bottom()

        cv2.rectangle(focus_frame, (x1, y1), (x2, y2), (0, 255, 0), 2)

        landmarks = predictor(gray, face)
        landmarks = face_utils.shape_to_np(landmarks)

        left_gaze_ratio = gaze_ratio([36, 37, 38, 39, 40, 41], landmarks)
        right_gaze_ratio = gaze_ratio([42, 43, 44, 45, 46, 47], landmarks)
        gaze_ratio_value = (left_gaze_ratio + right_gaze_ratio) / 2.0

        left_eye_closed = landmarks[37][1] < landmarks[36][1] and landmarks[40][1] < landmarks[39][1]
        right_eye_closed = landmarks[44][1] < landmarks[45][1] and landmarks[47][1] < landmarks[42][1]

        left_blink = blinked(landmarks[36], landmarks[37], landmarks[38], landmarks[41], landmarks[40], landmarks[39])
        right_blink = blinked(landmarks[42], landmarks[43], landmarks[44], landmarks[47], landmarks[46], landmarks[45])

        # Judge what to do for not focus and gaze ratio
        if left_blink == 0 and right_blink == 0:
            notfocus += 1
            focus = 0
            if notfocus > 6:
                status = "Not Focus :|"
                color = (0, 0, 255)
            if notfocus > 200:
                status = "BANGUN WOII :/"
                winsound.Beep(1000, 500)  # Beep sound with 1000 Hz frequency for 500 milliseconds
                color = (128, 0, 128)

        if left_eye_closed and right_eye_closed:
            sleep += 1
            notfocus = focus = 0
            if sleep > 6:
                status = "BANGUN WOII :/"
                winsound.Beep(1000, 500)  # Beep sound with 1000 Hz frequency for 500 milliseconds
                color = (128, 0, 128)

        if left_blink == 0 or right_blink == 0:
            notfocus += 1
            focus = 0
            if notfocus > 6:
                status = "Not Focus :|"
                color = (0, 0, 255)
            if notfocus > 200:
                status = "BANGUN WOII :/"
                winsound.Beep(1000, 500)  # Beep sound with 1000 Hz frequency for 500 milliseconds
                color = (128, 0, 128)

        elif gaze_ratio_value < GAZE_RATIO_THRESH:
            notfocus += 1
            focus = 0
            if notfocus > 6:
                status = "Not Focus :|"
                color = (0, 0, 255)

        else:
            notfocus = 0
            focus += 1
            if focus > 6:
                status = "Focus :)"
                color = (0, 255, 0)

        cv2.putText(focus_frame, status, (100, 100), cv2.FONT_HERSHEY_TRIPLEX, 1.25, color, 3)

        # Draw landmarks for the whole face
        for (x, y) in landmarks:
            cv2.circle(focus_frame, (x, y), 1, (255, 255, 255), -1)

    # Determine engagement level based on focus status and emotion
    engagement_level = ""
    if status == "Focus :)":
        if label in ["Happy", "Neutral", "Surprise"]:
            engagement_level = "High Engagement"
        elif label in ["Sad", "Angry", "Disgust"]:
            engagement_level = "Neutral Engagement"
    elif status in ["Not Focus :|", "BANGUN WOII :/"]:
        engagement_level = "Low Engagement"
    
    # Write the data to CSV
    real_time = time.strftime('%Y-%m-%d %H:%M:%S', time.localtime())
    csv_writer.writerow([real_time, label, status, engagement_level])

    # Display the frames
    cv2.imshow("Emotion Detection", emotion_frame)
    cv2.imshow("Engagement Detection", focus_frame)

    # Exit on 'q' key press
    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

# Release the webcam and close windows
csv_file.close()
cv2.destroyAllWindows()

# Read the data from CSV
data = pd.read_csv('emotion_engagement_data.csv')

# Analyze and plot focus and engagement levels
focus_counts = data['Focus_Level'].value_counts(normalize=True) * 100
engagement_counts = data['Engagement_Level'].value_counts(normalize=True) * 100
emotion_counts = data['Emotion'].value_counts(normalize=True) * 100

# Create pie charts for focus level and emotions
plt.figure(figsize=(12, 6))

# Focus Level Pie Chart
plt.subplot(1, 2, 1)
plt.pie(focus_counts, labels=focus_counts.index, autopct='%1.1f%%', colors=sns.color_palette("viridis", len(focus_counts)))
plt.title('Focus Level Distribution')

# Emotion Pie Chart
plt.subplot(1, 2, 2)
plt.pie(emotion_counts, labels=emotion_counts.index, autopct='%1.1f%%', colors=sns.color_palette("viridis", len(emotion_counts)))
plt.title('Emotion Distribution')

plt.show()

# Combine emotion and engagement level into a single state
data['State'] = data['Emotion'] + " - " + data['Engagement_Level']

# Count the occurrences of each state
state_counts = data['State'].value_counts().reset_index()
state_counts.columns = ['State', 'Count']
state_counts_pivot = state_counts.pivot_table(index='State', values='Count', aggfunc='sum')

# Visualize the heatmap
plt.figure(figsize=(12, 8))
sns.heatmap(state_counts_pivot, annot=True, fmt="d", cmap="coolwarm", cbar=True)
plt.title("Heatmap of Emotions and Engagement Levels")
plt.xlabel("State")
plt.ylabel("Count")
plt.xticks(rotation=45, ha='right')
plt.yticks(rotation=0)
plt.show()
